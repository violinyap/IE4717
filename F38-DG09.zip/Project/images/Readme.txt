Folder for images used

use orderlist;

insert into orders values
  (1, "1", "null","1", "Single", "1", "Single", "8.75"),
  (2, "1", "null","1", "Double", "1", "Double", "8.75");
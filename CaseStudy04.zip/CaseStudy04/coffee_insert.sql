use orderlist;

insert into coffee values
  (NULL, "Just Java", "Endless Cup", 2.00),
  (NULL, "Cafe au Lait", "Single", 2.00),
  (NULL, "Cafe au Lait", "Double", 3.00),
  (NULL, "Iced Cappuccino", "Single", 4.75),
  (NULL, "Iced Cappuccino", "Double", 5.75);
create table coffee
( coffee_id int unsigned not null auto_increment primary key,
  coffee_name char(50) not null,
  coffee_type char(50) not null,
  coffee_price float unsigned
);